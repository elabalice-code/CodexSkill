# Project Workspace Template

Use this template to initialize a project workspace. Replace generic descriptions only after the project name, scope, roles, and directory conventions are confirmed.

At session start, read `00_STATUS/README.md`, `00_STATUS/01_本轮目的.md`, and `00_STATUS/02_当前状态.md` in that order.

## Folder Structure

| Folder | Purpose |
|--------|---------|
| `00_STATUS/` | **Project tracking and governance.** Current objective, status, decisions, risks, handoffs, and team responsibilities. |
| `0_Codes/` | **Source and implementation artifacts.** Use when the project contains code or other primary implementation files. |
| `1_UserInpus/` | **User inputs.** Original requirements, constraints, examples, and other owner-provided materials. |
| `999_Docs/` | **Supporting documentation.** Agent-maintained research, explanations, and derived project documents. |
