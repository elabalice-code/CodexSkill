# 03 Decision Log

> Prepend confirmed project decisions. Do not record a proposal as a decision.

---

### YYYY-MM-DD - Topic

Decision:

Evidence:

Build gates:
