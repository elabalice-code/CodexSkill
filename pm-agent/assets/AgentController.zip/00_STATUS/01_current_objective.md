# Compatibility Entry

The canonical objective is [01_本轮目的.md](01_本轮目的.md). Do not maintain a second copy here.
