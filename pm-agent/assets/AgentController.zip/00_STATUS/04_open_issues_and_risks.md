# 04 Open Issues And Risks

> Last updated: 

## Active Risks


## Closed This Pass