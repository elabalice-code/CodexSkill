# Compatibility Entry

The canonical status is [02_当前状态.md](02_当前状态.md). Do not maintain a second copy here.
