# 06 Team Roles And Responsibilities

> This file is the single source of truth for the project's confirmed roles and responsibility boundaries.
> Maintainer:
> Last updated:

---

## Confirmed Roles

| Role | Positioning | Core Responsibilities | Key Inputs | Key Outputs | Out Of Scope |
|---|---|---|---|---|---|

No roles have been confirmed yet.

## Collaboration Boundaries

Record only boundaries that have been explicitly confirmed for this project.

## Maintenance Rules

- When a role is added or a responsibility boundary changes, update this file first.
- Record the confirmed rationale in `03_decision_log.md`.
- Add a handoff note to `05_agent_handoff_log.md`.
- Keep schedules and task progress in `02_当前状态.md`, not in this file.
