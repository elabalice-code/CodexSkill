# 00_STATUS 控制舱 / 驾驶舱

本目录是项目目标、状态和治理记录的事实源。每次进入项目 workspace，依次读取：

1. `README.md`
2. `01_本轮目的.md`
3. `02_当前状态.md`

## 文档分工

| 文件 | 用途 |
|---|---|
| `01_本轮目的.md` | 当前北极星、范围、交付物与完成定义 |
| `02_当前状态.md` | 当前阶段、进展、下一步与阻塞 |
| `03_decision_log.md` | 已确认的项目决策及依据 |
| `04_open_issues_and_risks.md` | 未决事项、风险与关闭项 |
| `05_agent_handoff_log.md` | 跨 Agent 或跨会话交接 |
| `06_team_roles_and_responsibilities.md` | 已确认的团队角色、权责和边界 |

`01_current_objective.md` 与 `02_current_status.md` 仅作为旧命名兼容入口，不承载第二份状态。
